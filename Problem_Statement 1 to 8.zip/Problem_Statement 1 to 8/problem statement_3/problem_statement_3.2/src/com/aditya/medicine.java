package com.aditya;

public class medicine
{
	public void displayLabel(){
	System.out.println("Company : divya patanjali");
	System.out.println("Address : patna");
	}
}

class Tablet extends medicine
{	 
public void displayLabel(){
	System.out.println("store in a cool dry place");
	}
}

class Syrup extends medicine
{
	public void displayLabel(){
		System.out.println("Consumption as directed by thephysician");
		}
	}

class Ointment extends medicine{
int[] arr;
int min = arr[0];  
//Loop through the array  
for (int i = 0; i < arr.length; i++) {  
    
//Compare elements of array with min  
   if(arr[i] <min)  
       min = arr[i];  
}  
System.out.println("Smallest element present in given array: " + min);  
	public void displayLabel(){
		System.out.println("for external use only");
		}
	}